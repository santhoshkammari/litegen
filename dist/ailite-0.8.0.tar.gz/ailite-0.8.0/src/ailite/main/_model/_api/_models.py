from .._base._base_llm import BaseLLM

class HUGPiLLM(BaseLLM):
    pass
